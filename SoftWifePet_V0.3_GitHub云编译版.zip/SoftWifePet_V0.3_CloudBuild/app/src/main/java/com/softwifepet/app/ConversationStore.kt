package com.softwifepet.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ChatTurn(val role: String, val text: String)

object ConversationStore {
    private const val PREFS = "chat_history"
    private const val KEY = "turns"
    private const val MAX_TURNS = 20

    fun load(context: Context): MutableList<ChatTurn> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                ChatTurn(o.optString("role"), o.optString("text"))
            }
        }.getOrElse { mutableListOf() }
    }

    fun add(context: Context, role: String, text: String) {
        val turns = load(context)
        turns.add(ChatTurn(role, text))
        while (turns.size > MAX_TURNS) turns.removeAt(0)
        save(context, turns)
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, "[]").apply()
    }

    private fun save(context: Context, turns: List<ChatTurn>) {
        val arr = JSONArray()
        turns.forEach { arr.put(JSONObject().put("role", it.role).put("text", it.text)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
