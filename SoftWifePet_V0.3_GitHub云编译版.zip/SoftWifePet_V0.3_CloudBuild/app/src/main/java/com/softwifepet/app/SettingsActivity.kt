package com.softwifepet.app

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    private lateinit var clingy: EditText
    private lateinit var jealous: EditText
    private lateinit var yandere: EditText
    private lateinit var reminder: EditText
    private lateinit var sleep: EditText
    private lateinit var scale: EditText
    private lateinit var autoStart: Switch
    private lateinit var cloud: Switch
    private lateinit var relayUrl: EditText
    private lateinit var relayToken: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    private fun buildUi(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "老婆桌宠设置 ♡"
            textSize = 25f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "病娇阈值单位为分钟，三个阶段需要依次增大。重新互动后占有欲会逐次软下来，不会瞬间清零。"
            textSize = 14f
            setPadding(0, dp(12), 0, dp(12))
        })

        clingy = numberField(root, "开始黏人", PetPrefs.clingyAfterMinutes(this))
        jealous = numberField(root, "开始吃醋", PetPrefs.jealousAfterMinutes(this))
        yandere = numberField(root, "病娇占有欲拉满", PetPrefs.yandereAfterMinutes(this))
        sleep = numberField(root, "空闲多久开始打瞌睡", PetPrefs.sleepAfterMinutes(this))
        reminder = numberField(root, "主动提醒间隔（至少 15）", PetPrefs.reminderMinutes(this))
        scale = numberField(root, "桌宠大小百分比（65～150）", PetPrefs.petScale(this))

        autoStart = Switch(this).apply {
            text = "开机后自动召唤老婆"
            isChecked = PetPrefs.autoStart(this@SettingsActivity)
        }
        root.addView(autoStart)

        root.addView(TextView(this).apply {
            text = "自由聊天"
            textSize = 21f
            setPadding(0, dp(20), 0, dp(8))
        })
        root.addView(TextView(this).apply {
            text = "本地模式无需网络。真正生成式自由聊天需要 HTTPS 云端中转；桌宠不要求把模型供应商永久密钥直接写进手机应用。"
            textSize = 13f
            setPadding(0, 0, 0, dp(8))
        })
        cloud = Switch(this).apply {
            text = "启用云端自由聊天"
            isChecked = PetPrefs.cloudEnabled(this@SettingsActivity)
        }
        root.addView(cloud)
        relayUrl = textField(root, "HTTPS 中转地址", PetPrefs.relayUrl(this))
        relayToken = EditText(this).apply {
            hint = "短期中转 Token（可留空）"
            setText(PetPrefs.relayToken(this@SettingsActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        root.addView(label("中转 Token"))
        root.addView(relayToken, LinearLayout.LayoutParams(-1, dp(56)))

        root.addView(Button(this).apply {
            text = "保存并刷新桌宠"
            setOnClickListener { saveSettings() }
        }, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(18) })

        root.addView(Button(this).apply {
            text = "哄好老婆 ♡"
            setOnClickListener {
                MoodEngine.soothe(this@SettingsActivity)
                Toast.makeText(this@SettingsActivity, "占有欲已经软下来啦♡", Toast.LENGTH_SHORT).show()
                refreshOverlay()
            }
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })

        root.addView(Button(this).apply {
            text = "清空聊天短期记忆"
            setOnClickListener {
                ConversationStore.clear(this@SettingsActivity)
                Toast.makeText(this@SettingsActivity, "短期聊天记录已经清空", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })

        return ScrollView(this).apply { addView(root) }
    }

    private fun saveSettings() {
        val c = clingy.text.toString().toIntOrNull() ?: 30
        val j = jealous.text.toString().toIntOrNull() ?: 120
        val y = yandere.text.toString().toIntOrNull() ?: 480
        val r = reminder.text.toString().toIntOrNull() ?: 30
        val s = sleep.text.toString().toIntOrNull() ?: 10
        val z = scale.text.toString().toIntOrNull() ?: 100
        if (c < 1 || j <= c || y <= j) {
            Toast.makeText(this, "三个病娇阈值需要按顺序变大", Toast.LENGTH_LONG).show()
            return
        }
        if (z !in 65..150) {
            Toast.makeText(this, "桌宠大小请输入 65～150", Toast.LENGTH_LONG).show()
            return
        }
        val url = relayUrl.text.toString().trim()
        if (cloud.isChecked && url.isNotBlank() && !url.startsWith("https://")) {
            Toast.makeText(this, "云端中转需要 HTTPS 地址", Toast.LENGTH_LONG).show()
            return
        }
        PetPrefs.saveThresholds(this, c, j, y, r.coerceAtLeast(15), s.coerceAtLeast(2), z, autoStart.isChecked)
        PetPrefs.saveCloud(this, cloud.isChecked, url, relayToken.text.toString())
        Toast.makeText(this, "保存好啦♡", Toast.LENGTH_SHORT).show()
        refreshOverlay()
    }

    private fun refreshOverlay() {
        val i = Intent(this, PetOverlayService::class.java).putExtra("reload", true)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun numberField(root: LinearLayout, title: String, value: Int): EditText {
        root.addView(label(title))
        return EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(value.toString())
            setSingleLine(true)
            root.addView(this, LinearLayout.LayoutParams(-1, dp(52)))
        }
    }

    private fun textField(root: LinearLayout, title: String, value: String): EditText {
        root.addView(label(title))
        return EditText(this).apply {
            setText(value)
            setSingleLine(true)
            root.addView(this, LinearLayout.LayoutParams(-1, dp(52)))
        }
    }

    private fun label(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 14f
        setPadding(0, dp(10), 0, dp(4))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
