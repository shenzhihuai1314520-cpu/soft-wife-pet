package com.softwifepet.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * 安全中转接口。桌宠不会要求把模型供应商的永久密钥直接写进 APK。
 * 中转端接收 persona/mood/history/input，并返回 {"reply":"..."}。
 */
object RemoteChatClient {
    fun reply(context: Context, userText: String, mood: PetMood): Result<String> = runCatching {
        val endpoint = PetPrefs.relayUrl(context).trim()
        require(endpoint.startsWith("https://")) { "中转地址需要使用 HTTPS" }

        val history = JSONArray()
        ConversationStore.load(context).forEach { turn ->
            history.put(JSONObject().put("role", turn.role).put("content", turn.text))
        }

        val body = JSONObject()
            .put("persona", Persona.instructions(mood))
            .put("mood", MoodEngine.moodLabel(mood))
            .put("affection", MoodEngine.affection(context))
            .put("history", history)
            .put("input", userText)

        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 70_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            val token = PetPrefs.relayToken(context).trim()
            if (token.isNotBlank()) setRequestProperty("Authorization", "Bearer $token")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = BufferedReader(InputStreamReader(stream)).use { it.readText() }
        if (code !in 200..299) error("云端中转返回错误 $code")
        parseReply(JSONObject(raw)).ifBlank { error("云端回复为空") }
    }

    private fun parseReply(root: JSONObject): String {
        root.optString("reply").takeIf { it.isNotBlank() }?.let { return it }
        root.optString("output_text").takeIf { it.isNotBlank() }?.let { return it }
        val out = root.optJSONArray("output") ?: JSONArray()
        val parts = mutableListOf<String>()
        for (i in 0 until out.length()) {
            val item = out.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val c = content.optJSONObject(j) ?: continue
                c.optString("text").takeIf { it.isNotBlank() }?.let(parts::add)
            }
        }
        return parts.joinToString("\n").trim()
    }
}
