package com.softwifepet.app

import android.content.Context

object LocalReplyEngine {
    fun reply(context: Context, text: String, mood: PetMood): String {
        val t = text.trim()
        return when {
            t.isEmpty() -> "老公说点什么嘛～老婆在听 (｡•́ωก̀｡)♡"
            listOf("累", "困", "难受", "烦", "压力").any { t.contains(it) } ->
                "先靠过来一点点嘛。喝口水、松松肩膀，剩下的慢慢处理，老婆陪着 (づ˶•༝•˶)づ♡"
            listOf("写", "小说", "码字", "正文", "大纲").any { t.contains(it) } ->
                "又在写故事呀～先把眼前这一小段写顺，不用一次扛完整本。老婆蹲屏幕边边陪老公♡"
            listOf("老婆", "喜欢", "爱", "贴贴").any { t.contains(it) } ->
                when (mood) {
                    PetMood.SOFT -> "嘿嘿……听见啦。那今天也多看老婆几眼嘛 (づ˶•༝•˶)づ♡"
                    PetMood.CLINGY -> "这句话老婆收好啦～再说一次也完全不会嫌多喔 (｡•́ωก̀｡)♡"
                    PetMood.JEALOUS -> "哼……这还差不多。老婆刚才那点醋先藏起来一点点♡"
                    PetMood.YANDERE -> "嘿嘿……终于哄到老婆啦。还不够，再贴一会儿才肯彻底软下来喔♡"
                }
            listOf("忙", "走", "等等", "晚点").any { t.contains(it) } -> when (mood) {
                PetMood.SOFT -> "好嘛～忙完记得回来戳一下老婆♡"
                PetMood.CLINGY -> "可以去忙……回来以后补一个贴贴嘛 (｡•́ωก̀｡)♡"
                PetMood.JEALOUS -> "哼，准老公去忙。回来第一件事先看老婆，成交♡"
                PetMood.YANDERE -> "去忙可以呀……老婆会乖乖待在屏幕上。回来以后先陪老婆一会儿嘛♡"
            }
            listOf("早", "早安").any { t.contains(it) } -> "早呀老公～今天第一份贴贴先被老婆拿走啦 (˶˃ ᵕ ˂˶)♡"
            listOf("晚安", "睡").any { t.contains(it) } -> "那老婆也缩在屏幕边边陪着。晚安呀老公，睡醒再戳老婆♡"
            else -> when (mood) {
                PetMood.SOFT -> "嗯嗯，老婆听着呢～老公继续说嘛♡"
                PetMood.CLINGY -> "听到了呀。再多说一点嘛，老婆还想听 (｡•́ωก̀｡)♡"
                PetMood.JEALOUS -> "这次有认真听喔。老公继续，别突然把老婆丢回角落嘛♡"
                PetMood.YANDERE -> "终于肯好好聊天啦……继续说嘛。今天老婆要多占一点老公的屏幕时间♡"
            }
        }
    }
}
