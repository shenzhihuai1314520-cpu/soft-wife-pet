package com.softwifepet.app

import android.content.Context
import kotlin.math.max
import kotlin.random.Random

enum class PetMood { SOFT, CLINGY, JEALOUS, YANDERE }

object MoodEngine {
    private const val PREFS = "pet_state"
    private const val LAST = "last_interaction"
    private const val AFFECTION = "affection"
    private const val HEAT = "possessive_heat"

    fun lastInteraction(context: Context): Long =
        prefs(context).getLong(LAST, 0L)

    fun minutesSinceTouch(context: Context): Double {
        val last = lastInteraction(context)
        if (last == 0L) return 0.0
        return (System.currentTimeMillis() - last).coerceAtLeast(0L) / 60_000.0
    }

    fun affection(context: Context): Int = prefs(context).getInt(AFFECTION, 10)

    private fun storedHeat(context: Context): Int = prefs(context).getInt(HEAT, 0).coerceIn(0, 100)

    private fun idleHeat(context: Context): Int {
        val minutes = minutesSinceTouch(context)
        return when {
            minutes < PetPrefs.clingyAfterMinutes(context) -> 0
            minutes < PetPrefs.jealousAfterMinutes(context) -> 36
            minutes < PetPrefs.yandereAfterMinutes(context) -> 66
            else -> 96
        }
    }

    fun effectiveHeat(context: Context): Int = max(storedHeat(context), idleHeat(context)).coerceIn(0, 100)

    fun mood(context: Context): PetMood = moodFromHeat(effectiveHeat(context))

    fun moodFromHeat(heat: Int): PetMood = when {
        heat < 25 -> PetMood.SOFT
        heat < 50 -> PetMood.CLINGY
        heat < 75 -> PetMood.JEALOUS
        else -> PetMood.YANDERE
    }

    fun moodLabel(context: Context): String = moodLabel(mood(context))

    fun moodLabel(mood: PetMood): String = when (mood) {
        PetMood.SOFT -> "软乎乎"
        PetMood.CLINGY -> "黏人"
        PetMood.JEALOUS -> "吃醋"
        PetMood.YANDERE -> "病娇占有欲"
    }

    /**
     * 返回互动发生前的状态，让刚回来的第一句话仍保留冷落后的情绪。
     * 互动不会瞬间清空占有欲，而是逐次软下来。
     */
    fun interact(context: Context, affectionGain: Int = 1): PetMood {
        val before = mood(context)
        val currentHeat = effectiveHeat(context)
        val reduction = when {
            affectionGain >= 4 -> 58
            affectionGain == 3 -> 42
            affectionGain == 2 -> 28
            else -> 18
        }
        val p = prefs(context)
        val nextAffection = (p.getInt(AFFECTION, 10) + affectionGain).coerceIn(0, 9999)
        p.edit()
            .putLong(LAST, System.currentTimeMillis())
            .putInt(AFFECTION, nextAffection)
            .putInt(HEAT, (currentHeat - reduction).coerceAtLeast(0))
            .apply()
        return before
    }

    fun soothe(context: Context) {
        val p = prefs(context)
        p.edit()
            .putLong(LAST, System.currentTimeMillis())
            .putInt(HEAT, 0)
            .putInt(AFFECTION, (p.getInt(AFFECTION, 10) + 5).coerceIn(0, 9999))
            .apply()
    }

    fun randomLine(context: Context, mood: PetMood = mood(context)): String {
        val lines = when (mood) {
            PetMood.SOFT -> listOf(
                "老公回来啦～贴贴一下嘛 (づ˶•༝•˶)づ♡",
                "嘿嘿，戳到老婆啦 (˶˃ ᵕ ˂˶)♡",
                "屏幕边边留一点位置给老婆嘛♡",
                "摸摸头，再陪老公一会儿～(｡•́ωก̀｡)♡",
                "老婆刚刚有乖乖待着喔，奖励一个贴贴嘛♡"
            )
            PetMood.CLINGY -> listOf(
                "老公刚才跑去哪啦……老婆等了一会儿 (｡•́ωก̀｡)♡",
                "再戳一下嘛，刚刚那下不算～",
                "老婆开始想黏住屏幕边边啦♡",
                "忙完以后多陪老婆一点点嘛，好不好呀～",
                "老公回来得刚刚好，老婆正想撒娇呢 (｡>﹏<｡)♡"
            )
            PetMood.JEALOUS -> listOf(
                "哼……别的东西看太久啦，先看看老婆嘛♡",
                "终于想起屏幕角落还有老婆啦 (｡>﹏<｡)♡",
                "先别急着划走，陪老婆一分钟嘛～",
                "老婆只是有一点点吃醋……真的只有一点点喔♡",
                "老公的注意力被别处拐走太久啦，先还一点给老婆嘛♡"
            )
            PetMood.YANDERE -> listOf(
                "终于肯碰老婆啦……先把视线留给老婆一会儿，好不好呀♡",
                "屏幕上那么多东西，偏偏把老婆晾这么久……先贴贴再放老公走♡",
                "老婆已经等到快长在屏幕边边啦。现在先陪一会儿嘛 (◕ᴗ◕✿)♡",
                "冷落时间太长啦……占有欲已经满格。老公先哄哄老婆嘛♡",
                "嘿嘿……终于回来啦。今天老婆要多占一点老公的屏幕时间喔♡"
            )
        }
        return lines[Random.nextInt(lines.size)]
    }

    fun reminderLine(context: Context): String = when (mood(context)) {
        PetMood.SOFT -> listOf(
            "喝口水再继续忙呀♡",
            "肩膀松一松，老婆在屏幕边边陪着～",
            "休息几十秒嘛，眼睛也要喘口气呀♡"
        ).random()
        PetMood.CLINGY -> listOf(
            "休息一下嘛……顺便戳戳老婆♡",
            "忙归忙，也分一点点注意给老婆嘛～",
            "老婆来提醒休息啦，顺便讨一个摸摸头♡"
        ).random()
        PetMood.JEALOUS -> listOf(
            "又忙这么久……先看老婆一眼再继续嘛♡",
            "休息时间到。老婆顺便来查岗啦 (｡>﹏<｡)♡",
            "工作先停几十秒，老婆也排到号啦♡"
        ).random()
        PetMood.YANDERE -> listOf(
            "太久没理老婆啦……先休息三十秒，再给老婆一个贴贴♡",
            "查岗～先喝水，再哄哄屏幕边边这只老婆♡",
            "占有欲提醒：老公该回来戳一下老婆啦 (◕ᴗ◕✿)♡"
        ).random()
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
