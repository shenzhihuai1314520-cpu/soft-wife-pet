package com.softwifepet.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
    }

    private fun buildUi(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "软乎乎老婆桌宠 V0.3.0 ♡"
            textSize = 26f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "单击说话 · 双击聊天 · 长按贴贴 · 拖动换位置\n睡觉 / 生气 / 吃醋 / 病娇 / 贴贴动作已经加入"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(16))
        })
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.wife_pet)
            adjustViewBounds = true
            maxHeight = dp(310)
        }, LinearLayout.LayoutParams(-1, dp(300)))

        button(root, "召唤老婆到屏幕上") { ensureOverlayAndStart() }
        button(root, "打开老婆聊天") { startActivity(Intent(this, ChatActivity::class.java)) }
        button(root, "设置病娇阈值 / 云端聊天") { startActivity(Intent(this, SettingsActivity::class.java)) }
        button(root, "哄好老婆 ♡") {
            MoodEngine.soothe(this)
            reloadPet()
            Toast.makeText(this, "老婆被哄软啦♡", Toast.LENGTH_SHORT).show()
        }
        button(root, "先让老婆休息") { stopService(Intent(this, PetOverlayService::class.java)) }

        root.addView(TextView(this).apply {
            text = "首次使用需要开启悬浮窗权限。没有云端中转时，本地互动照常工作；双击聊天页还能直接打开 ChatGPT。"
            textSize = 13f
            setPadding(0, dp(14), 0, 0)
        })
        return ScrollView(this).apply { addView(root) }
    }

    private fun button(root: LinearLayout, textValue: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = textValue
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) })
    }

    private fun ensureOverlayAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                101
            )
        } else startPet()
    }

    private fun startPet() {
        val i = Intent(this, PetOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
        Toast.makeText(this, "老婆已经趴到屏幕上啦♡", Toast.LENGTH_SHORT).show()
    }

    private fun reloadPet() {
        val i = Intent(this, PetOverlayService::class.java).putExtra("reload", true)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && Settings.canDrawOverlays(this)) startPet()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
