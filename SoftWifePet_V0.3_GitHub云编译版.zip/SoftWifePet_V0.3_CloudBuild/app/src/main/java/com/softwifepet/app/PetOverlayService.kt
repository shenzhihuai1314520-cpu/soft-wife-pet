package com.softwifepet.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class PetOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private var bubble: TextView? = null
    private var effect: TextView? = null
    private var pet: ImageView? = null
    private lateinit var params: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var bubbleHide: Runnable? = null
    private var tapCount = 0
    private var tapWindowStart = 0L

    private val reminder = object : Runnable {
        override fun run() {
            if (root != null) {
                showBubble(MoodEngine.reminderLine(this@PetOverlayService), 8000)
                animateForMood(force = true)
            }
            handler.postDelayed(this, PetPrefs.reminderMinutes(this@PetOverlayService) * 60_000L)
        }
    }

    private val idleWatcher = object : Runnable {
        override fun run() {
            if (root != null) animateForMood(force = false)
            handler.postDelayed(this, 20_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(77, notification())
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        addOverlay()
        scheduleLoops()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getBooleanExtra("reload", false) == true) {
            removeOverlay()
            addOverlay()
            scheduleLoops()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?) = null

    private fun scheduleLoops() {
        handler.removeCallbacks(reminder)
        handler.removeCallbacks(idleWatcher)
        handler.postDelayed(reminder, PetPrefs.reminderMinutes(this) * 60_000L)
        handler.postDelayed(idleWatcher, 20_000L)
    }

    private fun addOverlay() {
        if (root != null) return
        val scale = PetPrefs.petScale(this) / 100f
        val width = (225 * scale).toInt()
        val height = (350 * scale).toInt()
        params = WindowManager.LayoutParams(
            dp(width), dp(height),
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(PetPrefs.petX(this@PetOverlayService))
            y = dp(PetPrefs.petY(this@PetOverlayService))
        }

        val frame = FrameLayout(this)
        pet = ImageView(this).apply {
            setImageResource(R.drawable.wife_pet)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(4), dp(58), dp(4), 0)
        }
        bubble = TextView(this).apply {
            text = MoodEngine.randomLine(this@PetOverlayService)
            textSize = 13.5f
            setTextColor(Color.rgb(35, 35, 40))
            setBackgroundColor(Color.argb(238, 255, 255, 255))
            setPadding(dp(10), dp(7), dp(10), dp(7))
            elevation = dp(6).toFloat()
        }
        effect = TextView(this).apply {
            text = "♡"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(65, 65, 75))
            visibility = View.INVISIBLE
        }

        frame.addView(pet, FrameLayout.LayoutParams(-1, -1))
        frame.addView(bubble, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            leftMargin = dp(6)
            rightMargin = dp(6)
        })
        frame.addView(effect, FrameLayout.LayoutParams(dp(70), dp(48), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(62)
            rightMargin = dp(6)
        })
        root = frame
        runCatching { wm.addView(frame, params) }.onFailure {
            stopSelf()
            return
        }
        animateForMood(force = true)

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                val moodBefore = MoodEngine.interact(this@PetOverlayService, 1)
                registerTapBurst()
                showBubble(MoodEngine.randomLine(this@PetOverlayService, moodBefore))
                pet?.let { view ->
                    if (tapCount >= 5) {
                        showEffect("💢", 1300)
                        PetAnimator.angry(view) { animateForMood(force = false) }
                    } else if (moodBefore == PetMood.SOFT) {
                        showEffect("♡", 1100)
                        PetAnimator.happy(view) { animateForMood(force = false) }
                    } else {
                        showEffect("♡", 1100)
                        PetAnimator.cuddle(view) { animateForMood(force = false) }
                    }
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                MoodEngine.interact(this@PetOverlayService, 2)
                showEffect("♡♡", 1200)
                pet?.let { PetAnimator.startled(it) { animateForMood(force = false) } }
                val i = Intent(this@PetOverlayService, ChatActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(i)
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                val before = MoodEngine.interact(this@PetOverlayService, 3)
                val line = when (before) {
                    PetMood.SOFT -> "贴贴成功～再抱紧一点点 (づ˶•༝•˶)づ♡"
                    PetMood.CLINGY -> "终于肯抱老婆啦……再多一会儿嘛 (｡•́ωก̀｡)♡"
                    PetMood.JEALOUS -> "哼……这个抱抱先收下，醋还剩一点点喔♡"
                    PetMood.YANDERE -> "嘿嘿……抓到老公啦。先抱够再慢慢软下来♡"
                }
                showBubble(line, 6500)
                showEffect("♡♡♡", 1800)
                pet?.let { PetAnimator.cuddle(it) { animateForMood(force = false) } }
            }
        })

        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var dragging = false
        frame.setOnTouchListener { _, event ->
            detector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    downX = event.rawX
                    downY = event.rawY
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) dragging = true
                    if (dragging) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        runCatching { wm.updateViewLayout(frame, params) }
                    }
                }
                MotionEvent.ACTION_UP -> if (dragging) {
                    MoodEngine.interact(this@PetOverlayService, 1)
                    snapToEdge(frame)
                    showEffect("~", 700)
                    showBubble("老公把老婆搬到这里啦～♡", 2600)
                    pet?.let { PetAnimator.cling(it) }
                }
            }
            true
        }
    }

    private fun snapToEdge(frame: View) {
        val displayWidth: Int
        val displayHeight: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val bounds = wm.currentWindowMetrics.bounds
            displayWidth = bounds.width()
            displayHeight = bounds.height()
        } else {
            @Suppress("DEPRECATION")
            val dm = resources.displayMetrics
            displayWidth = dm.widthPixels
            displayHeight = dm.heightPixels
        }
        val margin = dp(6)
        val targetX = if (params.x + frame.width / 2 < displayWidth / 2) margin
        else max(margin, displayWidth - frame.width - margin)
        val targetY = min(max(params.y, margin), max(margin, displayHeight - frame.height - margin))
        params.x = targetX
        params.y = targetY
        runCatching { wm.updateViewLayout(frame, params) }
        PetPrefs.savePosition(this, pxToDp(targetX), pxToDp(targetY))
    }

    private fun registerTapBurst() {
        val now = System.currentTimeMillis()
        if (now - tapWindowStart > 2800L) {
            tapWindowStart = now
            tapCount = 1
        } else tapCount += 1
    }

    private fun animateForMood(force: Boolean) {
        val view = pet ?: return
        val minutes = MoodEngine.minutesSinceTouch(this)
        val current = MoodEngine.mood(this)
        val shouldSleep = minutes >= PetPrefs.sleepAfterMinutes(this) && current == PetMood.SOFT
        if (shouldSleep) {
            if (force) showEffect("Zzz", 2200)
            PetAnimator.sleep(view)
            return
        }
        when (current) {
            PetMood.SOFT -> PetAnimator.breathe(view)
            PetMood.CLINGY -> {
                if (force) showEffect("♡", 1300)
                PetAnimator.cling(view)
            }
            PetMood.JEALOUS -> {
                if (force) showEffect("…♡", 1500)
                PetAnimator.jealous(view)
            }
            PetMood.YANDERE -> {
                if (force) showEffect("♡♡", 1600)
                PetAnimator.yandere(view)
            }
        }
    }

    private fun showBubble(text: String, ms: Long = 5000L) {
        bubble?.apply {
            this.text = text
            visibility = View.VISIBLE
        }
        bubbleHide?.let { handler.removeCallbacks(it) }
        bubbleHide = Runnable { bubble?.visibility = View.INVISIBLE }
        handler.postDelayed(bubbleHide!!, ms)
    }

    private fun showEffect(text: String, ms: Long) {
        effect?.apply {
            this.text = text
            alpha = 1f
            visibility = View.VISIBLE
            animate().cancel()
            animate().alpha(0f).translationY(-dp(16).toFloat()).setDuration(ms).withEndAction {
                visibility = View.INVISIBLE
                translationY = 0f
            }.start()
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel("pet", "老婆桌宠", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }

    private fun notification(): Notification = NotificationCompat.Builder(this, "pet")
        .setContentTitle("老婆正在屏幕边边陪着♡")
        .setContentText("单击互动 · 双击聊天 · 长按贴贴")
        .setSmallIcon(android.R.drawable.star_on)
        .setOngoing(true)
        .build()

    private fun removeOverlay() {
        pet?.let { PetAnimator.cancel(it) }
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        pet = null
        bubble = null
        effect = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeOverlay()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun pxToDp(v: Int) = (v / resources.displayMetrics.density).toInt()
}
