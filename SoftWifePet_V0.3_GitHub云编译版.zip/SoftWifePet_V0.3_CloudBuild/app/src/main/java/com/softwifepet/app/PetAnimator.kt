package com.softwifepet.app

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.BounceInterpolator
import android.view.animation.LinearInterpolator

object PetAnimator {
    private var current: Animator? = null

    fun cancel(view: View) {
        current?.cancel()
        current = null
        view.animate().cancel()
        view.rotation = 0f
        view.scaleX = 1f
        view.scaleY = 1f
        view.translationX = 0f
        view.translationY = 0f
        view.alpha = 1f
    }

    fun breathe(view: View) {
        cancel(view)
        val sx = ObjectAnimator.ofFloat(view, View.SCALE_X, 1f, 1.018f, 1f).apply {
            duration = 2600
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        val sy = ObjectAnimator.ofFloat(view, View.SCALE_Y, 1f, 1.018f, 1f).apply {
            duration = 2600
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        current = AnimatorSet().apply { playTogether(sx, sy); start() }
    }

    fun happy(view: View, onEnd: (() -> Unit)? = null) {
        cancel(view)
        val y = ObjectAnimator.ofFloat(view, View.TRANSLATION_Y, 0f, -20f, 0f, -8f, 0f).apply {
            duration = 720
            interpolator = BounceInterpolator()
        }
        val r = ObjectAnimator.ofFloat(view, View.ROTATION, 0f, -3f, 3f, 0f).apply { duration = 720 }
        val set = AnimatorSet().apply { playTogether(y, r) }
        addEnd(set, onEnd)
        current = set.apply { start() }
    }

    fun cling(view: View) {
        cancel(view)
        val r = ObjectAnimator.ofFloat(view, View.ROTATION, -1.7f, 1.7f, -1.7f).apply {
            duration = 1800
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        current = r.apply { start() }
    }

    fun jealous(view: View) {
        cancel(view)
        val x = ObjectAnimator.ofFloat(view, View.TRANSLATION_X, 0f, -7f, 7f, -5f, 5f, 0f).apply {
            duration = 760
            repeatCount = 1
        }
        val r = ObjectAnimator.ofFloat(view, View.ROTATION, 0f, -2.5f, 2.5f, 0f).apply { duration = 760 }
        current = AnimatorSet().apply { playTogether(x, r); start() }
    }

    fun yandere(view: View) {
        cancel(view)
        val scaleX = ObjectAnimator.ofFloat(view, View.SCALE_X, 1f, 1.042f, 1f).apply {
            duration = 1450
            repeatCount = ObjectAnimator.INFINITE
        }
        val scaleY = ObjectAnimator.ofFloat(view, View.SCALE_Y, 1f, 1.042f, 1f).apply {
            duration = 1450
            repeatCount = ObjectAnimator.INFINITE
        }
        val rot = ObjectAnimator.ofFloat(view, View.ROTATION, -0.9f, 0.9f, -0.9f).apply {
            duration = 2200
            repeatCount = ObjectAnimator.INFINITE
        }
        current = AnimatorSet().apply { playTogether(scaleX, scaleY, rot); start() }
    }

    fun cuddle(view: View, onEnd: (() -> Unit)? = null) {
        cancel(view)
        view.animate()
            .scaleX(1.17f).scaleY(1.17f)
            .translationY(-13f)
            .setDuration(220)
            .withEndAction {
                view.animate().scaleX(1f).scaleY(1f).translationY(0f).setDuration(340)
                    .withEndAction { onEnd?.invoke() }.start()
            }.start()
    }

    fun angry(view: View, onEnd: (() -> Unit)? = null) {
        cancel(view)
        val x = ObjectAnimator.ofFloat(view, View.TRANSLATION_X, 0f, -17f, 17f, -13f, 13f, -8f, 8f, 0f).apply {
            duration = 650
        }
        addEnd(x, onEnd)
        current = x.apply { start() }
    }

    fun startled(view: View, onEnd: (() -> Unit)? = null) {
        cancel(view)
        val sx = ObjectAnimator.ofFloat(view, View.SCALE_X, 1f, 1.1f, 0.98f, 1f).apply { duration = 420 }
        val sy = ObjectAnimator.ofFloat(view, View.SCALE_Y, 1f, 1.1f, 0.98f, 1f).apply { duration = 420 }
        val set = AnimatorSet().apply { playTogether(sx, sy) }
        addEnd(set, onEnd)
        current = set.apply { start() }
    }

    fun sleep(view: View) {
        cancel(view)
        view.rotation = -4f
        val y = ObjectAnimator.ofFloat(view, View.TRANSLATION_Y, 0f, 5f, 0f).apply {
            duration = 3000
            repeatCount = ObjectAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
        }
        val a = ObjectAnimator.ofFloat(view, View.ALPHA, 1f, 0.91f, 1f).apply {
            duration = 3000
            repeatCount = ObjectAnimator.INFINITE
            interpolator = LinearInterpolator()
        }
        current = AnimatorSet().apply { playTogether(y, a); start() }
    }

    private fun addEnd(animator: Animator, onEnd: (() -> Unit)?) {
        if (onEnd == null) return
        animator.addListener(object : Animator.AnimatorListener {
            override fun onAnimationStart(animation: Animator) = Unit
            override fun onAnimationCancel(animation: Animator) = Unit
            override fun onAnimationRepeat(animation: Animator) = Unit
            override fun onAnimationEnd(animation: Animator) { onEnd.invoke() }
        })
    }
}
