package com.softwifepet.app

import android.content.Context

object PetPrefs {
    private const val PREFS = "pet_settings"

    fun clingyAfterMinutes(context: Context): Int = int(context, "clingy_after", 30)
    fun jealousAfterMinutes(context: Context): Int = int(context, "jealous_after", 120)
    fun yandereAfterMinutes(context: Context): Int = int(context, "yandere_after", 480)
    fun reminderMinutes(context: Context): Int = int(context, "reminder_minutes", 30).coerceAtLeast(15)
    fun sleepAfterMinutes(context: Context): Int = int(context, "sleep_after", 10).coerceAtLeast(2)
    fun petScale(context: Context): Int = int(context, "pet_scale", 100).coerceIn(65, 150)
    fun autoStart(context: Context): Boolean = prefs(context).getBoolean("auto_start", true)

    fun cloudEnabled(context: Context): Boolean = prefs(context).getBoolean("cloud_enabled", false)
    fun relayUrl(context: Context): String = prefs(context).getString("relay_url", "") ?: ""
    fun relayToken(context: Context): String = prefs(context).getString("relay_token", "") ?: ""

    fun petX(context: Context): Int = int(context, "pet_x", 18)
    fun petY(context: Context): Int = int(context, "pet_y", 150)

    fun saveThresholds(
        context: Context,
        clingy: Int,
        jealous: Int,
        yandere: Int,
        reminder: Int,
        sleep: Int,
        scale: Int,
        autoStart: Boolean
    ) {
        prefs(context).edit()
            .putInt("clingy_after", clingy)
            .putInt("jealous_after", jealous)
            .putInt("yandere_after", yandere)
            .putInt("reminder_minutes", reminder)
            .putInt("sleep_after", sleep)
            .putInt("pet_scale", scale)
            .putBoolean("auto_start", autoStart)
            .apply()
    }

    fun saveCloud(context: Context, enabled: Boolean, url: String, token: String) {
        prefs(context).edit()
            .putBoolean("cloud_enabled", enabled)
            .putString("relay_url", url.trim())
            .putString("relay_token", token.trim())
            .apply()
    }

    fun savePosition(context: Context, x: Int, y: Int) {
        prefs(context).edit().putInt("pet_x", x).putInt("pet_y", y).apply()
    }

    private fun int(context: Context, key: String, fallback: Int): Int = prefs(context).getInt(key, fallback)
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
