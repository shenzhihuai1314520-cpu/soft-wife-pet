package com.softwifepet.app

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class ChatActivity : AppCompatActivity() {
    private lateinit var log: TextView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var send: Button
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        val previous = ConversationStore.load(this)
        if (previous.isEmpty()) {
            append("老婆", MoodEngine.randomLine(this))
        } else {
            previous.forEach { append(if (it.role == "assistant") "老婆" else "老公", it.text) }
        }
        refreshStatus()
    }

    private fun buildUi(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "和老婆说话 ♡"
            textSize = 24f
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        val scroll = ScrollView(this)
        log = TextView(this).apply {
            textSize = 16f
            setPadding(dp(6), dp(6), dp(6), dp(14))
        }
        scroll.addView(log)
        progress = ProgressBar(this).apply { visibility = View.GONE }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        input = EditText(this).apply {
            hint = "跟老婆聊点什么……"
            maxLines = 4
        }
        send = Button(this).apply {
            text = "发送"
            setOnClickListener { sendMessage() }
        }
        row.addView(input, LinearLayout.LayoutParams(0, dp(58), 1f))
        row.addView(send, LinearLayout.LayoutParams(dp(88), dp(58)))

        val openChatGpt = Button(this).apply {
            text = "打开 ChatGPT 继续自由聊"
            setOnClickListener { openChatGpt() }
        }

        root.addView(status)
        root.addView(progress, LinearLayout.LayoutParams(dp(36), dp(36)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(row)
        root.addView(openChatGpt, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
        return root
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty() || !send.isEnabled) return
        append("老公", text)
        input.setText("")
        ConversationStore.add(this, "user", text)
        val moodBefore = MoodEngine.interact(this, 2)
        refreshStatus()

        val cloudReady = PetPrefs.cloudEnabled(this) && PetPrefs.relayUrl(this).startsWith("https://")
        if (!cloudReady) {
            val reply = LocalReplyEngine.reply(this, text, moodBefore)
            append("老婆", reply)
            ConversationStore.add(this, "assistant", reply)
            refreshStatus()
            return
        }

        setBusy(true)
        thread {
            val result = RemoteChatClient.reply(this, text, moodBefore)
            runOnUiThread {
                val reply = result.getOrElse {
                    "云端刚刚没接上……先让本地老婆陪老公嘛 (｡•́ωก̀｡)♡\n\n" +
                        LocalReplyEngine.reply(this, text, moodBefore)
                }
                append("老婆", reply)
                ConversationStore.add(this, "assistant", reply)
                setBusy(false)
                refreshStatus()
            }
        }
    }

    private fun openChatGpt() {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/"))
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "暂时找不到可打开网页的应用", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setBusy(busy: Boolean) {
        send.isEnabled = !busy
        input.isEnabled = !busy
        progress.visibility = if (busy) View.VISIBLE else View.GONE
    }

    private fun refreshStatus() {
        val mode = if (PetPrefs.cloudEnabled(this) && PetPrefs.relayUrl(this).startsWith("https://")) "云端自由聊天" else "本地互动"
        status.text = "亲密度 ${MoodEngine.affection(this)} · ${MoodEngine.moodLabel(this)} · $mode"
    }

    private fun append(who: String, text: String) {
        log.append("$who：$text\n\n")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
